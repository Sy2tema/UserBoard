create table userboard (
  userid varchar2(50) not null primary key,
  password varchar2(50) not null,
  username varchar2(50) not null,
  email varchar2(50) not null,
  signupdate date default sysdate
);

insert into userboard (userid, password, username, email)
values ('test', '1234', 'Kim', 'test@testsite.com');

select * from userboard;

commit;