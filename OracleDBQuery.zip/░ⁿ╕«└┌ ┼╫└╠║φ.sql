create table admin (
  userid varchar2(50) not null primary key,
  password varchar2(50) not null,
  username varchar2(50) not null,
  email varchar2(50) not null,
  signupdate date default sysdate
);

insert into admin (userid, password, username, email)
values ('admin', 'spring', '������', 'admin@adminsite.com');

select * from admin;

commit;